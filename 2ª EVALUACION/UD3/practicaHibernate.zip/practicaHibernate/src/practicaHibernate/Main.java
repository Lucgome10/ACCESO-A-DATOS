package practicaHibernate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

	private static ArrayList<Proyecto> proyectos = new ArrayList<>();
	private static ArrayList<Empleado> empleados = new ArrayList<>();
	private static ArrayList<Tarea> tareas = new ArrayList<>();
	
		
	public static void main(String[] args) {
		
		//PASO 1: Crear proyectos Simples y empleados Simples.
		
//		crearProyectos();
//		for (Proyecto p : proyectos) {
//			System.out.println(p);
//		}
//		
//		
		crearEmpleados();
//		for (Empleado e : empleados) {
//			System.out.println(e + "\n");
//		}
		
		
		//PASO 2: Asignar proyectos a cada empleado [0-3].
		asignarProyectoAEmpleado();
		
		
	}
	

	public static void crearProyectos () {		
		//ProyectoS con:
//		- duracion
//		- nombreProyecto
//		- fechaInicio
//		- fechaFin

		try (Session s = HibernateUtil.getSessionFactory().openSession()) {
			Transaction t = null;
			try {
				t = s.beginTransaction();

				int numProyectos = (int) ((Math.random() * 4) + 3);

				for (int i = 0; i < numProyectos; i++) {

					int duracion = (int) ((Math.random() * 9) + 4);
					int semanasAntelacion = (int) ((Math.random() * 3) + 6); 

					Calendar calendar = Calendar.getInstance();
					Date fechaHoy = calendar.getTime();

					calendar.add(Calendar.WEEK_OF_YEAR, -semanasAntelacion);
					Date fechaInicio = calendar.getTime();

					calendar.add(Calendar.WEEK_OF_YEAR, duracion);

					Proyecto proyecto = new Proyecto();
					String nombreProyecto = "Proyecto" + (i+1);
					proyecto.setDuracion(duracion);
					proyecto.setNombreProyecto(nombreProyecto);
					proyecto.setFechaInicio(fechaInicio);

					if (fechaHoy.after(calendar.getTime())) {
						Date fechaFin = calendar.getTime();
						proyecto.setFechaFin(fechaFin);
					} else {
						//System.out.println("El proyecto no ha terminado todav�a.");
					}
					s.save(proyecto);
					proyectos.add(proyecto);
				}
				t.commit();
			} catch (Exception e) {
				e.printStackTrace(System.err);
				if (t != null) {
					t.rollback();
				}
			}
		}
	}

	
	public static void crearEmpleados() {

		try (Session s = HibernateUtil.getSessionFactory().openSession()) {
			Transaction t = null;
			try {
				t = s.beginTransaction();



				ArrayList<Empleado> empleados = new ArrayList<>();

				ArrayList<String> nombres = new ArrayList<>(Arrays.asList("Fernando", "Marta", "Sancho", "Gregorio", "Sandra", "Leonor", "Ildefonso", "Mario", "Alba", "Luc�a"));
				ArrayList<String> apellidos = new ArrayList<>(Arrays.asList("Mart�n", "Fern�ndez", "Heredia", "de Marcos", "Carret�n", "Blanco", "Missis", "Arranz", "Ovejero", "Aldeaga"));
				String letras = "ABCDEFGHIJKLMN�OPQRSTUVWXYZ";
				String[] letrasString = letras.split("");

				for (int i = 0; i < 20; i++) { // Se generan 20 empleados.

					Empleado empleado = new Empleado();

					int numDni = (int) ((Math.random() * 90000000) + 10000000);
					int numLetraDni = (int) ((Math.random() * letrasString.length));
					String dni = numDni + letrasString[numLetraDni];

					int numNombre = (int) ((Math.random() * 10));
					String nombre = nombres.get(numNombre);
					int numApellido1 = (int) ((Math.random() * 10));
					String apellido1 = apellidos.get(numApellido1);
					int numApellido2 = (int) ((Math.random() * 10));
					String apellido2 = apellidos.get(numApellido2);
					String apellido = apellido1 + " " + apellido2;

					// Solo genera m�viles que empiezan por 6.
					String telefono = String.valueOf ((int) ((Math.random()*100000000) + 600000000));

					empleado.setDni(dni);
					empleado.setNombre(nombre);
					empleado.setApellidos(apellido);
					empleado.setTelefono(telefono);

					empleados.add(empleado);

					s.save(empleado);

				}
				t.commit();

			} catch (Exception e) {
				e.printStackTrace(System.err);
				if (t != null) {
					t.rollback();
				}
			}

		}
	}
	
	
	
	public static void asignarProyectoAEmpleado () {

		try (Session s = HibernateUtil.getSessionFactory().openSession()) {
			Transaction t = null;
			try {
				t = s.beginTransaction();


				for (Empleado empleado : empleados) { // Asignar proyectos a cada uno de los empleados de la empresa.
					String nombre = empleado.getNombre();

					int numeroProyectos = (int) (Math.random() * 4); // n�mero de proyectos entre 0 y 3.
					System.out.println("El empleado " + nombre + " tiene asignados " + numeroProyectos + " proyectos.");
					for (int j = 0; j < numeroProyectos; j++) { // m�ximo 4 proyectos por empleado, n�mero aleatorio entre 0 y 3.
						int numProyectoDeLista = (int) (Math.random() * proyectos.size()); // n�mero de proyecto aleatorio de la lista de proyectos.
						Proyecto p = proyectos.get(numProyectoDeLista); // Proyecto aleatorio de la lista de proyectos.
						if (empleado.getProyectos().contains(p)) {
							j--; // Si el empleado ya tiene ese proyecto asignado, repite la iteraci�n.
						} else {
							empleado.getProyectos().add(p); // si el empleado no tiene el proyecto asignado, lo asigna.
						}
					}
					s.save(empleado);
				}
				t.commit();

			} catch (Exception e) {
				e.printStackTrace(System.err);
				if (t != null) {
					t.rollback();
				}
			}

		}
	}
	
	
	
	public static ArrayList<Tarea> crearTareas() {
		
		ArrayList<Tarea> tareas = new ArrayList<>();
		
		Tarea tarea = new Tarea(); // Falta ver cu�ntas tareas ser�n generadas en el bucle.
		
		//Generar estado y nombre de forma aleatoria.
		ArrayList<String> estados = new ArrayList<>(Arrays.asList("PLANIFICADA", "EMPEZADA", "FINALIZADA"));	
		ArrayList<String> nombres = new ArrayList<>(Arrays.asList("An�lisis", "Dise�o", "Codificaci�n", "Pruebas", "Documentaci�n"));
		int numNombreTarea = (int) (Math.random() * nombres.size());
		int numEstadoTarea = (int) (Math.random() * estados.size());
		String nombreTarea = nombres.get(numNombreTarea);
		String estadoTarea = estados.get(numEstadoTarea);
		
		int horas = (int) ((Math.random() * 9) + 2);

		
		//Asignar la Tarea a un Proyecto.
		int numProyectoTarea = (int) (Math.random() * proyectos.size());
		Proyecto p = proyectos.get(numProyectoTarea);
		if (p.getFechaFin() != null) {
			tarea.setEstado("FINALIZADA");
		} else {
			tarea.setEstado(estadoTarea);
		}
		
		// para cada Tarea se asignar� un n�mero aleatorio de entre 0 y 2 empleados.
		int numEmpleadosTarea = (int) (Math.random() * 3);
		for (int j = 0; j < numEmpleadosTarea; j++) {
			int numEmpleadoAleatorio = generarAleatorio(0, 2);
			Empleado e = empleados.get(numEmpleadoAleatorio);
			if (tarea.getEmpleados().contains(e)) {
				j--;
			} else {
				tarea.getEmpleados().add(e);
			}			
		}

		
		return tareas;	
	}
	
	
	private static int generarAleatorio (int min, int max) {
		max++;
		int num = (int) ((Math.random() * (max-min)) + min);
		return num;	
	}

	
}








