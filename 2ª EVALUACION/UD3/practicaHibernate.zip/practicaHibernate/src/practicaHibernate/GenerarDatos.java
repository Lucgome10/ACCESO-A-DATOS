package practicaHibernate;

public class GenerarDatos {
	
	

	public void crearProyectos () {
		// Generate random number between 0 to 20  
        double a = (Math.random() * 4) + 3;
        System.out.println(a);
        double b = Math.random() * 20;  
	}

}


